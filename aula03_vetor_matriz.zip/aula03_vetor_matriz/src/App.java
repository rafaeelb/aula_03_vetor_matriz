import java.util.Arrays;

public class App {
    public static void main(String[] args) throws Exception {
        int[] meu_array = new int[5];

        meu_array[0] = 10;
        meu_array[1] = 20;
        meu_array[2] = 30;
        meu_array[3] = 40;
        meu_array[4] = 50;

        // recuperar os elementos do array por acesso rápido
        // int element0 = meu_array[0];
        // int element1 = meu_array[1];
        // System.out.println(element0);   
        // System.out.println(element1);  
        
        // for (int i = 0; i < meu_array.length; i++) {
        //     System.out.println("Elemento " + i + ": " + meu_array[i]);
        // }

        String[] lista_aluno = new String[5];
        lista_aluno[0] = "não existe aluno 0";
        lista_aluno[1] = "Rafael";
        lista_aluno[2] = "Artur";
        lista_aluno[3] = "Yasmin";
        lista_aluno[4] = "Tayna";

        // for (int i = 0; i < lista_aluno.length; i++) {
        //     System.out.println("Aluno " + i + ": " + lista_aluno[i]);
        // }

        String[]lista_cidade = {"Poá","Itaim Paulista","Suzano", "Itu"};
        // System.out.println(lista_cidade[2]);
        // System.out.println("---------------------------------");
        // for (int i = 0; i < lista_cidade.length; i++) {
        //     System.out.println("Cidade "+i+": "+lista_cidade[i]);
        // }

        int[] array={1,2,3,4,5};
        System.out.println(Arrays.toString(array));
        System.out.println(array.length);

        int[] copia = array.clone();
        String[]copia_cidade = lista_cidade;

        System.out.println("Copia" + Arrays.toString(copia_cidade));
        System.out.println("Copia" + Arrays.toString(copia));

        //organizando elementos
        int[] nova_array = {5,6,4,2,3,1,0};
        Arrays.sort(nova_array);
        System.out.println("Ordenada em: "+ Arrays.toString(nova_array));

        //inserindo um valor igual em todas as posiçoes
        int [] array_vazia = new int[5];
        System.out.println(Arrays.toString(array_vazia));

        //preencher arrays vazios
        Arrays.fill(array_vazia,10);
        System.out.println(": " +Arrays.toString(array_vazia));

        //  aqui é sem a utilização do if, criando uma variavel local para a verificação
        // boolean resp = Arrays.equals(copia_cidade, lista_cidade);
        // System.out.println("Os arrays sao iguais " +resp);

        // utilizando if else
        if (Arrays.equals(lista_cidade,copia_cidade)) {
            System.out.println("Elas são iguais");
        } else {
            System.out.println("Elas são diferentes");
        }

        int posicao = Arrays.binarySearch(array, 3);
        System.out.println("Foi localizado na posição: " + posicao);
    }
}
